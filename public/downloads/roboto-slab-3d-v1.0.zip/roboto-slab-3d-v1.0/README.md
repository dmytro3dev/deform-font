# Roboto Slab Bold — deform-ready 3D font

161 glyphs of Roboto Slab Bold as clean quad meshes, built to be subdivided and deformed
(twist, bend, taper, stretch) without breaking. Latin, digits, symbols and the
Ukrainian Cyrillic alphabet.

Live demo: https://deform-font.dmytro3dev.com

## What is inside

| Folder | Format | Use it in |
|---|---|---|
| `blender/` | `.blend` | Blender 5.x. Collections per character set, Subdivision Surface level 3 already on every glyph. |
| `web/` | `.json` + `.bin` + TypeScript | three.js / React Three Fiber. Quantized meshes, advance widths, kerning and a Catmull-Clark implementation. |

## Geometry

- Every glyph is a closed, manifold, all-quad mesh (median ~620 quads before subdivision).
- Use Catmull-Clark subdivision, level 2 or 3. The outer support loop keeps the silhouette tight.
- Units: cap height is 2.06, depth is 0.4 (centred on the glyph plane).
- Each object's origin is the pen position on the baseline, exactly like in the font,
  so glyphs can be set as text with the advance widths and kerning from `web/robotoslab.json`.
- Object names: `cap_A`, `low_a` (uppercase / lowercase letters, Latin and Cyrillic),
  `num_0` (digits), PostScript names for symbols (`ampersand`, `question`, ...).
  The Ukrainian apostrophe is `cap_’`.

## Character set

Latin A–Z a–z, digits 0–9, ASCII symbols, Ukrainian Cyrillic А–Я а–я (with Ґ Є І Ї)
and the apostrophe. Other Cyrillic letters (Ё Ъ Ы Э) are not included.

## License

The font is Apache License 2.0. See `LICENSE.txt` and `NOTICE.txt`.
The 3D meshes are a modified version of the font and are distributed under the same license.
